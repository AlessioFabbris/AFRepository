select 'UPDATE tab_registro SET DATA_CHIUSURA = to_date(''' || data_chiusura || ''', ''dd/mm/yyyy'') where id_registro = ' || id_registro || ';'
from tab_registro
where anno = 2017;

DELETE
from TAB_MONITORAGGIO_QUEST
where anno_quest = 2018;



