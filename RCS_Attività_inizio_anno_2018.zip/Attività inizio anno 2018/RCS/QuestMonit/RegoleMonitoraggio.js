//********************************************************************
//gestisce i permessi a livello di sezione 
//chiamata dalla pagina sinistra 
//   Pino     | 23/01/2009   |  Gestione monitoraggio 2008
function permessi(sez, annoquest)
{
  
  //QUESTIONARIO DEI REGISTRI DEL  2005
  if (annoquest=="2005")	
  {
			if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="A")  
			{
			//	alert(document.forms[0].flg_cdc.value);	
				if (document.forms[0].flg_cdc.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se si � un Centro di Coordinamento");
				   }  
			}
			else if (sez=="C")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_ing.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se si hanno rifiuti ingombranti");
				   }  
			}
			else if (sez=="E")  
			{
				//alert(document.forms[0].flg_cantiere.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se si ha un cantiere aperto");
				   }  
			}
			else
			{
				//controllo generico prima devi compilare anagrafica
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
					
				}	
			}
    }	
    
    //QUESTIONARIO DEI REGISTRI DEL  2008
    else if (annoquest == "2008")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }

    //QUESTIONARIO DEI REGISTRI DEL  2009
   
    else if (annoquest == "2009")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }

    //QUESTIONARIO DEI REGISTRI DEL  2010
   
    else if (annoquest == "2010")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
				alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }



    //QUESTIONARIO DEI REGISTRI DEL  2011
   
    else if (annoquest == "2011")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
				alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }
    //QUESTIONARIO DEI REGISTRI DEL  2012
   
    else if (annoquest == "2012")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
				alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }

	//Inizio modifica TIIT-NAPOLI - 27/02/2014
    //QUESTIONARIO DEI REGISTRI DEL  2013
   
    else if (annoquest == "2013")
    {
    		if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
				alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
			//	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
    	
    }
    //Fine modifica TIIT-NAPOLI - 27/02/2014

    //Inizio modifica ATOS 5/02/2015
    //QUESTIONARIO DEI REGISTRI DEL  2014
    else if (annoquest == "2014") {
        if (sez == "0")    //L'anagrafica sempre permessa
        {
            return true;
        }
        else if (sez == "C") {
            alert(document.forms[0].flg_dep_temp.value);
            if (document.forms[0].flg_dep_ing.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
            }
        }
        else if (sez == "B") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_dep_temp.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo");
            }
        }
        else if (sez == "D") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_cantiere.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un cantiere");
            }
        }

        else {
            //controllo generico prima devi compilare anagrafica
            //	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
            if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N")) {
                return true;
            }
            else {
                alert("Bisogna compilare prima la sezione Anagrafica");
            }
        }

    }
    //Fine modifica ATOS 5/02/2015

    //Inizio modifica ATOS 12/02/2016
    //QUESTIONARIO DEI REGISTRI DEL  2015
    else if (annoquest == "2015") {
        if (sez == "0")    //L'anagrafica sempre permessa
        {
            return true;
        }
        else if (sez == "C") {
            alert(document.forms[0].flg_dep_temp.value);
            if (document.forms[0].flg_dep_ing.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
            }
        }
        else if (sez == "B") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_dep_temp.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo");
            }
        }
        else if (sez == "D") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_cantiere.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un cantiere");
            }
        }

        else {
            //controllo generico prima devi compilare anagrafica
            //	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
            if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N")) {
                return true;
            }
            else {
                alert("Bisogna compilare prima la sezione Anagrafica");
            }
        }

    }
    //Fine modifica ATOS 12/02/2016

    //Inizio modifica ATOS 06/04/2017
    //QUESTIONARIO DEI REGISTRI DEL  2016
    else if (annoquest == "2016") 
    {
        if (sez == "0")    //L'anagrafica sempre permessa
        {
            return true;
        }
        else if (sez == "C") {
            alert(document.forms[0].flg_dep_temp.value);
            if (document.forms[0].flg_dep_ing.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
            }
        }
        else if (sez == "B") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_dep_temp.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo");
            }
        }
        else if (sez == "D") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_cantiere.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un cantiere");
            }
        }

        else {
            //controllo generico prima devi compilare anagrafica
            //	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
            if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N")) {
                return true;
            }
            else {
                alert("Bisogna compilare prima la sezione Anagrafica");
            }
        }

    }
    //Fine modifica ATOS 06/04/2017
	
    //Inizio modifica REPLY - 18/04/2018
    //QUESTIONARIO DEI REGISTRI DEL  2017
    else if (annoquest == "2017") 
    {
        if (sez == "0")    //L'anagrafica sempre permessa
        {
            return true;
        }
        else if (sez == "C") {
            alert(document.forms[0].flg_dep_temp.value);
            if (document.forms[0].flg_dep_ing.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombranti TI.TIS.");
            }
        }
        else if (sez == "B") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_dep_temp.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un deposito temporaneo");
            }
        }
        else if (sez == "D") {
            //	alert(document.forms[0].flg_dep_temp.value);	
            if (document.forms[0].flg_cantiere.value == "S") {
                return true;
            }
            else {
                alert("Sezione attiva solo se � presente un cantiere");
            }
        }

        else {
            //controllo generico prima devi compilare anagrafica
            //	alert(document.forms[0].flg_cdc.value + " " + document.forms[0].flg_cdc.value);
            if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N")) {
                return true;
            }
            else {
                alert("Bisogna compilare prima la sezione Anagrafica");
            }
        }

    }
    //Fine modifica REPLY - 18/04/2018	
	

    //QUESTIONARIO DEI REGISTRI DEL  2007
    else if (annoquest=="2007")	
    {
		  
			if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombrfanti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
  	}
    //QUESTIONARIO DEI REGISTRI DEL  2006
    else if (annoquest=="2006")	
    {
  
			if (sez=="0")    //L'anagrafica sempre permessa
			{
				return true;
			}
			else if (sez=="C")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_ing.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo di rifiuti ingombrfanti TI.TIS.");
				   }  
			}
			else if (sez=="B")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_dep_temp.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un deposito temporaneo");
				   }  
			}
			else if (sez=="D")  
			{
			//	alert(document.forms[0].flg_dep_temp.value);	
				if (document.forms[0].flg_cantiere.value == "S")
				   {
				   	return true;
				   }
				else
				   {
				   	alert("Sezione attiva solo se � presente un cantiere");
				   }  
			}
			
			else
			{
				//controllo generico prima devi compilare anagrafica
				if ((document.forms[0].flg_cdc.value == "S") || (document.forms[0].flg_cdc.value == "N"))
				{	
					return true;
				}
				else
				{
					alert("Bisogna compilare prima la sezione Anagrafica");
				}	
			}
  	
    }
return false;
}






//*************************************************************************************
//**********************************************************************
//mette a 0 i valori hidden della sezione nella parte sinistra
//chiamata dalla parte destra del monitoraggio
//
function resettaSezione(sez)
{
	var inizioSezione;
	var fineSezione;
	var i;
	var controllo;
	
	inizioSezione = 0;
	fineSezione = 0 ;
	//alert("inizio resettaSezione  " + sez + " " +parent.frames["sinistra"].document.forms[0].length);
	for (i=0; i < parent.frames["sinistra"].document.forms[0].length; i++)
	{
		controllo = parent.frames["sinistra"].document.forms[0].elements[i];
		if ((controllo.name.charAt(0) == sez) && (inizioSezione == 0))
		{
			inizioSezione = i;
		}
		if ((controllo.name.charAt(0) != sez) && (inizioSezione > 0) && (fineSezione == 0))
		{
			fineSezione = i;
		}
	}
	// alert("Inizio Sezione " +inizioSezione+ " fine sezione " + fineSezione);
	for(i=inizioSezione ; i < fineSezione ; i++)
	{
		controllo = parent.frames["sinistra"].document.forms[0].elements[i];
		if (controllo.type == "hidden")
		{
			controllo.value="";
		}
	}
}



//**********************************************************************
// funzione che setta i valori dipendenti all'interno della stessa sezione
//**********************************************************************
function controllaDipendenze(annoquest, dom)
{
	var sez;
	sez = dom.substring(0,1);
	//alert("controllaDipendenze" + annoquest + " " + sez);
	if (annoquest=="2005")
	{
		if ((sez=='A') && (document.forms[0].Ad1[1].checked==true))
			{	
			document.forms[0].Ad2[2].checked=true; 
			}
		if ((sez=='F') && (document.forms[0].Fd1[1].checked==true))
			{	
			document.forms[0].Fd2[2].checked=true; 
			}
		if ((sez=='G') && (document.forms[0].Gd9[0].checked==true))
			{	
			document.forms[0].Gd10[2].checked=true; 
			}		
		if ((sez=='H') && (document.forms[0].Hd1[1].checked==true))
			{	
			document.forms[0].Hd2[2].checked=true; 
			}
	}
	else if (annoquest=="2006")
	{
		//vincoli su sezione e
		//ed1
		if (dom=="Ed1")
		{
			//se E1=no  allora E2 � non app
			if (document.forms[0].Ed1[1].checked==true)
			{
				document.forms[0].Ed2[2].checked=true;
				document.forms[0].Ed2[0].disabled=true;
				document.forms[0].Ed2[1].disabled=true;
				document.forms[0].Ed2[2].disabled=true;
				
			} 
			//se E1=Si allora E2 � attiva
			else if (document.forms[0].Ed1[0].checked==true) 
			{
				document.forms[0].Ed2[0].disabled=false;
				document.forms[0].Ed2[1].disabled=false;
				document.forms[0].Ed2[2].disabled=false;
				document.forms[0].Ed2[0].checked=false;
				document.forms[0].Ed2[1].checked=false;
				document.forms[0].Ed2[2].checked=false;
			} 

		}
		//vincoli su sezione f
		//fd9
		if (dom=="Fd9")
		{
			//se f9=si o non presente allora f10 � no
			if (document.forms[0].Fd9[0].checked==true)
			{
				document.forms[0].Fd10[2].checked=true;
				document.forms[0].Fd10[0].disabled=true;
				document.forms[0].Fd10[1].disabled=true;
				document.forms[0].Fd10[2].disabled=true;
				
			} 
			//se f9=nO allora f10 � attiva
			else if ((document.forms[0].Fd9[1].checked==true) || (document.forms[0].Fd9[2].checked==true))
			{
				document.forms[0].Fd10[0].disabled=false;
				document.forms[0].Fd10[1].disabled=false;
				document.forms[0].Fd10[2].disabled=false;
				document.forms[0].Fd10[0].checked=false;
				document.forms[0].Fd10[1].checked=false;
				document.forms[0].Fd10[2].checked=false;
			} 

		}
		//vincoli su sezione g
		//Gd1
		if (dom=="Gd1")
		{
			if (document.forms[0].Gd1[1].checked==true) //gd1 a no
			{
				document.forms[0].Gd3[2].checked=true; //NP
				document.forms[0].Gd3[0].disabled=true;
				document.forms[0].Gd3[1].disabled=true;
				document.forms[0].Gd3[2].disabled=true;
				
				document.forms[0].Gd5[2].checked=true; //NP
				document.forms[0].Gd5[0].disabled=true ;
				document.forms[0].Gd5[1].disabled=true ;
				document.forms[0].Gd5[2].disabled=true ;
				
				document.forms[0].Gd6[2].checked=true; //NP
				document.forms[0].Gd6[0].disabled=true;
				document.forms[0].Gd6[1].disabled=true;
				document.forms[0].Gd6[2].disabled=true;
				
				document.forms[0].Gd8.value=0;         //0
				document.forms[0].Gd8.disabled=true;
				document.forms[0].Gd9.value=0;		//0
				document.forms[0].Gd9.disabled=true;
				document.forms[0].Gd10.value=0;		//0
				document.forms[0].Gd10.disabled=true;
				
				document.forms[0].Gd11.value=0;
				document.forms[0].Gd11.disabled=true;
				
				document.forms[0].Gd12.value=0;
				document.forms[0].Gd12.disabled=true;
				
				document.forms[0].Gd13.value=0;
				document.forms[0].Gd13.disabled=true;
				
				document.forms[0].Gd14.value=0;
				document.forms[0].Gd14.disabled=true;
				
				document.forms[0].Gd15.value=0;
				document.forms[0].Gd15.disabled=true;
				
			}
			else
			{
				document.forms[0].Gd3[0].disabled=false;
				document.forms[0].Gd3[1].disabled=false;
				document.forms[0].Gd3[2].disabled=false;
												
				document.forms[0].Gd5[0].disabled=false ;
				document.forms[0].Gd5[1].disabled=false ;
				document.forms[0].Gd5[2].disabled=false ;
				
				//document.forms[0].Gd6[2].checked=false; //NP
				document.forms[0].Gd6[0].disabled=false;
				document.forms[0].Gd6[1].disabled=false;
				document.forms[0].Gd6[2].disabled=false;
				
				document.forms[0].Gd8.disabled=false;
				document.forms[0].Gd8.value="";         //0
				
				document.forms[0].Gd9.disabled=false;
				document.forms[0].Gd9.value="";		//0
				
				document.forms[0].Gd10.disabled=false;
				document.forms[0].Gd10.value="";		//0
				
				document.forms[0].Gd11.disabled=false;
				document.forms[0].Gd11.value="";
								
				document.forms[0].Gd12.disabled=false;
				document.forms[0].Gd12.value="";
								
				document.forms[0].Gd13.disabled=false;
				document.forms[0].Gd13.value="";
								
				document.forms[0].Gd14.disabled=false;
				document.forms[0].Gd14.value="";
						
				document.forms[0].Gd15.disabled=false;				
				document.forms[0].Gd15.value="";
			}
		}
		if (dom=="Gd15")
		{
			if(document.forms[0].Gd15.value=="0")
			{
				document.forms[0].Gd16.value="0";
				document.forms[0].Gd16.disabled=true;
			}
			else
			{
				document.forms[0].Gd16.disabled=false;
				document.forms[0].Gd16.value="0";
			}
		}
		if (dom=="Gd20")
		{
			if(document.forms[0].Gd20.value=="0")
			{
				document.forms[0].Gd21.value="0";
				document.forms[0].Gd21.disabled=true;
			}
			else
			{
				document.forms[0].Gd21.disabled=false;
				document.forms[0].Gd21.value="0";
			}

		}
		if (dom=="Gd21")
		{
			
			if(document.forms[0].Gd21.value=="0")
			{
				document.forms[0].Gd22.value="0";
				document.forms[0].Gd22.disabled=true;
			}
			else
			{
				document.forms[0].Gd22.disabled=false;
				document.forms[0].Gd22.value="0";
			}
			
		}
	//fine vincoli su sezione g
	//vincoli sezione h
		if (dom=="Hd1")
		{
			alert(document.forms[0].Hd1.value);
			if(document.forms[0].Hd1.value=="0")
			{
				document.forms[0].Hd2.value="0";
				document.forms[0].Hd2.disabled=true;
			}
			else
			{
				document.forms[0].Hd2.disabled=false;
				document.forms[0].Hd2.value="0";
			}			
		}
	//fine vincoli sezione h
	}
	else if (annoquest=="2007")
	{
		//Controllo sezione C 
		//se C1 = NP allora c2, c3 sono NP
		if (sez=="C")
		{
			if (document.forms[0].Cd1[2].checked)
			{
				document.forms[0].Cd2[2].checked = true;
				document.forms[0].Cd3[2].checked = true;
				
			}
		}	
		//fine controllo sezione C
		//Controllo sezione F
		if (sez=="F")
		{

			//mettiamo a np la domanda f1 e disabilitiamo
			document.forms[0].Fd1[2].checked;
			document.forms[0].Fd1[0].enabled = false;
			document.forms[0].Fd1[1].enabled = false;
			document.forms[0].Fd1[2].enabled = false;
			//se f9 a no allora f10 a no
			if (document.forms[0].Fd9[1].checked)
			{
				document.forms[0].Fd10[1].checked;
				document.forms[0].Fd10[1].enabled = false;
			}
			else
			{
			
				document.forms[0].Fd10[1].enabled = true;
			}
		}	
	}
	
	else if (annoquest=="2008")
	{
		//Controllo sezione C 
		//se C1 = NP allora c2, c3 sono NP
		if (sez=="C")
		{
			if (document.forms[0].Cd1[2].checked)
			{
				document.forms[0].Cd2[2].checked = true;
				document.forms[0].Cd3[2].checked = true;
				
			}
		}	
		//fine controllo sezione C
		//Controllo sezione F
		if (sez=="F")
		{
			//alert("Stai nel 2008 sezione F");
			//mettiamo a np la domanda f1 e la abilitiamo
			//document.forms[0].Fd1[2].checked;
			document.forms[0].Fd1[0].enabled = true;
			document.forms[0].Fd1[1].enabled = true;
			document.forms[0].Fd1[2].enabled = true;
			//se f9 a no allora f10 a no
			if (document.forms[0].Fd9[1].checked)
			{
				document.forms[0].Fd10[1].checked;
				document.forms[0].Fd10[1].enabled = false;
			}
			else
			{
			
				document.forms[0].Fd10[1].enabled = true;
			}
		}	
	}
	else if (annoquest=="2009")
	{
		//Controllo sezione C 
		//se C1 = NP allora c2, c3 sono NP
		if (sez=="C")
		{
			if (document.forms[0].Cd1[2].checked)
			{
				document.forms[0].Cd2[2].checked = true;
				document.forms[0].Cd3[2].checked = true;
				
			}
		}	
		//fine controllo sezione C
		//Controllo sezione F
		if (sez=="F")
		{
			//alert("Stai nel 2008 sezione F");
			//mettiamo a np la domanda f1 e la abilitiamo
			//document.forms[0].Fd1[2].checked;
			document.forms[0].Fd1[0].enabled = true;
			document.forms[0].Fd1[1].enabled = true;
			document.forms[0].Fd1[2].enabled = true;
			//se f9 a no allora f10 a no
			if (document.forms[0].Fd9[1].checked)
			{
				document.forms[0].Fd10[1].checked;
				document.forms[0].Fd10[1].enabled = false;
			}
			else
			{
			
				document.forms[0].Fd10[1].enabled = true;
			}
		}	
	}
	else if (annoquest=="2010")
	{
		//Controllo sezione C 
		//se C1 = NP allora c2, c3 sono NP
		if (sez=="C")
		{
			if (document.forms[0].Cd1[2].checked)
			{
				document.forms[0].Cd2[2].checked = true;
				document.forms[0].Cd3[2].checked = true;
				
			}
		}	
		//fine controllo sezione C
		//Controllo sezione F
		if (sez=="F")
		{
			//alert("Stai nel 2010 sezione F");
			//mettiamo a np la domanda f1 e la abilitiamo
			//document.forms[0].Fd1[2].checked;
			document.forms[0].Fd1[0].enabled = true;
			document.forms[0].Fd1[1].enabled = true;
			document.forms[0].Fd1[2].enabled = true;
			//se f9 a no allora f10 a no
			if (document.forms[0].Fd9[1].checked)
			{
				document.forms[0].Fd10[1].checked;
				document.forms[0].Fd10[1].enabled = false;
			}
			else
			{
			
				document.forms[0].Fd10[1].enabled = true;
			}
		}	
	}
}




//***************************************************************************
//ATTIVA DISATTIVA PER GRUPPO DI CONTROLLI  *********************************
//***************************************************************************
//Chiamata alla fine del caricamento serve a disabilitare i default
function settaDefault(annoquest, sez)
{
	if(annoquest=="2006")
	{
		//sezione e se e1 = no allora e2 disabilitata e NP
		if (sez=="E")
		{
			if (document.forms[0].Ed1[1].checked==true)
			{
				document.forms[0].Ed2[2].checked=true;
				document.forms[0].Ed2[0].disabled=true;
				document.forms[0].Ed2[1].disabled=true;
				document.forms[0].Ed2[2].disabled=true;
				
			}
		}
		if (sez=="F")
		{
			if (document.forms[0].Fd9[0].checked==true)
			{
				document.forms[0].Fd10[2].checked=true;
				document.forms[0].Fd10[0].disabled=true;
				document.forms[0].Fd10[1].disabled=true;
				document.forms[0].Fd10[2].disabled=true;
				
			} 
		}
		if (sez=="G")
		{
			if (document.forms[0].Gd1[1].checked==true) //gd1 a no
			{
				document.forms[0].Gd3[2].checked=true; //NP
				document.forms[0].Gd3[0].disabled=true;
				document.forms[0].Gd3[1].disabled=true;
				document.forms[0].Gd3[2].disabled=true;
				
				document.forms[0].Gd5[2].checked=true; //NP
				document.forms[0].Gd5[0].disabled=true ;
				document.forms[0].Gd5[1].disabled=true ;
				document.forms[0].Gd5[2].disabled=true ;
				
				document.forms[0].Gd6[2].checked=true; //NP
				document.forms[0].Gd6[0].disabled=true;
				document.forms[0].Gd6[1].disabled=true;
				document.forms[0].Gd6[2].disabled=true;
				
				document.forms[0].Gd8.value=0;         //0
				document.forms[0].Gd8.disabled=true;
				document.forms[0].Gd9.value=0;		//0
				document.forms[0].Gd9.disabled=true;
				document.forms[0].Gd10.value=0;		//0
				document.forms[0].Gd10.disabled=true;
				
				document.forms[0].Gd11.value=0;
				document.forms[0].Gd11.disabled=true;
				
				document.forms[0].Gd12.value=0;
				document.forms[0].Gd12.disabled=true;
				
				document.forms[0].Gd13.value=0;
				document.forms[0].Gd13.disabled=true;
				
				document.forms[0].Gd14.value=0;
				document.forms[0].Gd14.disabled=true;
				
				document.forms[0].Gd15.value=0;
				document.forms[0].Gd15.disabled=true;
				
			}
			if(document.forms[0].Gd15.value=="0")
			{
				document.forms[0].Gd16.value="0";
				document.forms[0].Gd16.disabled=true;
			}
			if(document.forms[0].Gd20.value=="0")
			{
				document.forms[0].Gd21.value="0";
				document.forms[0].Gd21.disabled=true;
			}
			if(document.forms[0].Gd21.value=="0")
			{
				document.forms[0].Gd22.value="0";
				document.forms[0].Gd22.disabled=true;
			}
		}
		if (sez=="H")
		{
			if(document.forms[0].Hd1.value=="0")
			{
				document.forms[0].Hd2.value="0";
				document.forms[0].Hd2.disabled=true;
			}

		}	
	}
	else if((annoquest=="2007") && (sez=="F"))
	{
			//alert("metto a disabled nuovo");
			document.forms[0].Fd1[2].checked = true;
			document.forms[0].Fd1[0].disabled = true;
			document.forms[0].Fd1[1].disabled = true;
			document.forms[0].Fd1[2].disabled = false;
	}
	/*
	else if((annoquest=="2008") && (sez=="F"))
	{
			//alert("metto a disabled nuovo");
			document.forms[0].Fd1[2].checked = true;
			document.forms[0].Fd1[0].disabled = false;
			document.forms[0].Fd1[1].disabled = false;
			document.forms[0].Fd1[2].disabled = false;
	}
	*/
}
